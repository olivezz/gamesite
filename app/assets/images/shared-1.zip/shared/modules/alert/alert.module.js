/**
 * @description alert module definition for alert messages
 * @name shared.modules.alert
 * @ngdoc module
 */
(function () {

    "use strict";

    angular
        .module('shared.modules.alert',[]);

}());

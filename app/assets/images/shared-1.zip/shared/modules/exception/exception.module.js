(function() {
    'use strict';

    angular.module('shared.modules.exception', [
        'shared.modules.alert'
    ]);
})();
